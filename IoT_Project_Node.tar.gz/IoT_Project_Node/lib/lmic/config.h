#ifndef _config_h_
#define _config_h_

#ifdef __cplusplus
extern "C" {
#endif

#define  CFG_sx1276_radio 1
#define CFG_eu868 1

#define US_PER_OSTICK 50

#ifdef __cplusplus
}
#endif

#endif

